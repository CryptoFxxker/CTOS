# 🎯 量化对冲策略系统

## 📋 策略总览

本目录包含三个核心对冲策略，支持多账户、多交易所并行运行，具备完整的断点续传功能。

| 策略名称 | 文件名 | 运行账户 | 策略特点 | 适用场景 | 状态 |
|---------|--------|---------|---------|---------|------|
| **马丁对冲网格** | `MartingHedgeGrid.py` | 2, 4 | 指数增长杠杆，波动大+次数多 | 高波动市场 | ✅ 运行中 |
| **渐进式对冲网格** | `ProgressiveHedgeGrid.py` | 0, 3 | 线性增长杠杆，波动小+次数多 | 低波动市场 | ✅ 运行中 |
| **狙击飞升对冲** | `SniperTakeoffHedge.py` | 0, 3, 4 | 监控飞升币种，动态轮换 | 趋势市场 | ✅ 运行中 |

---

## 🚀 快速开始

### 1. 环境准备
```bash
# 确保在项目根目录
cd /home/username/Quantify/ctos

# 检查依赖
python -c "from ctos.core.runtime.ExecutionEngine import pick_exchange; print('环境OK')"
```

### 2. 首次运行
```bash
# 运行任意策略（会自动创建配置文件）
python apps/strategies/hedge/MartingHedgeGrid.py
python apps/strategies/hedge/ProgressiveHedgeGrid.py  
python apps/strategies/hedge/SniperTakeoffHedge.py
```

### 3. 配置调整
- 编辑对应的配置文件（如 `marting_hedge_config.json`）
- 重启策略即可生效

---

## 📊 策略详解

### 1. 马丁对冲网格策略 (`MartingHedgeGrid.py`)

#### 🎯 策略原理
- **核心思想**：基于余额变化动态调整杠杆倍数
- **杠杆计算**：`0.1 * pow(2, add_times[idx]/2)` - 指数增长
- **触发条件**：余额跌破/突破目标线时加仓/减仓
- **适用场景**：高波动市场，适合快速响应价格变化

#### 📈 交易逻辑
```
余额下跌 → 加仓（增加杠杆）
余额上涨 → 减仓（减少杠杆）
```

#### ⚙️ 配置参数
```json
{
  "account_ids": [2, 4],                    // 账户ID
  "cexes": ["bp", "bp"],                     // 交易所
  "leverages": [0.3, 0.3],                  // 初始杠杆
  "max_leverages": [3.88, 3.88],            // 最大杠杆
  "min_leverages": [0.28, 0.28],            // 最小杠杆
  "add_position_rates": [0.00388, 0.00588], // 加仓触发比例
  "reduce_position_rates": [0.00488, 0.00688] // 减仓触发比例
}
```

#### 🔧 手动配置
1. **修改账户**：编辑 `account_ids` 和 `cexes`
2. **调整杠杆**：修改 `max_leverages`、`min_leverages`
3. **设置触发点**：调整 `add_position_rates`、`reduce_position_rates`
4. **重置状态**：设置 `need_to_init: [true, true]`

---

### 2. 渐进式对冲网格策略 (`ProgressiveHedgeGrid.py`)

#### 🎯 策略原理
- **核心思想**：线性增长杠杆，更温和的调整方式
- **杠杆计算**：`0.1 * (1 + add_times[idx]/20)` - 线性增长
- **触发条件**：与马丁策略相同，但杠杆增长更平缓
- **适用场景**：低波动市场，适合稳健操作

#### 📈 交易逻辑
```
余额下跌 → 加仓（线性增加杠杆）
余额上涨 → 减仓（线性减少杠杆）
```

#### ⚙️ 配置参数
```json
{
  "account_ids": [0, 3],                    // 账户ID
  "cexes": ["bp", "bp"],                     // 交易所
  "leverages": [0.3, 0.3],                  // 初始杠杆
  "max_leverages": [3.28, 3.28],            // 最大杠杆
  "min_leverages": [0.28, 0.28],            // 最小杠杆
  "add_position_rates": [0.00588, 0.00588], // 加仓触发比例
  "reduce_position_rates": [0.00588, 0.00588] // 减仓触发比例
}
```

#### 🔧 手动配置
1. **修改账户**：编辑 `account_ids` 和 `cexes`
2. **调整杠杆**：修改 `max_leverages`、`min_leverages`
3. **设置触发点**：调整 `add_position_rates`、`reduce_position_rates`
4. **重置状态**：设置 `need_to_init: [true, true]`

---

### 3. 狙击飞升对冲策略 (`SniperTakeoffHedge.py`)

#### 🎯 策略原理
- **核心思想**：监控币种相对BTC的涨幅，对"飞升"币种进行制裁
- **制裁条件**：币种涨幅超越BTC超过设定阈值（默认1%）
- **轮换机制**：卖出飞升币种，买入BTC/BNB等稳定币种
- **适用场景**：趋势市场，适合捕捉短期异常波动

#### 📈 交易逻辑
```
币种涨幅 > BTC涨幅 + 阈值 → 卖出该币种
选择BTC/BNB中涨幅较小的 → 买入
```

#### ⚙️ 配置参数
```python
# 制裁阈值（超越BTC涨幅的百分比）
sanction_line = 0.01  # 1%

# 制裁金额（每超1%准备多少USDT）
sanction_money = 3

# 目标币种池（买入候选）
target_pool = {'btc', 'bnb'}
```

#### 🔧 手动配置
1. **修改监控币种**：编辑 `good_group_bp.txt` 文件
2. **调整制裁阈值**：修改 `sanction_line` 值
3. **设置制裁金额**：修改 `sanction_money` 值
4. **选择目标币种**：修改 `target_pool` 集合

---

## 📁 文件结构

```
apps/strategies/hedge/
├── README.md                           # 本文档
├── MartingHedgeGrid.py                 # 马丁对冲网格策略
├── ProgressiveHedgeGrid.py             # 渐进式对冲网格策略
├── SniperTakeoffHedge.py              # 狙击飞升对冲策略
├── marting_hedge_config.json          # 马丁策略配置文件
├── progressive_hedge_config.json      # 渐进式策略配置文件
├── good_group_bp.txt                   # BP交易所关注币种
├── good_group_bp_martin.txt           # BP交易所马丁策略币种
├── SniperCoins/                       # 狙击策略关注币种配置
│   ├── bp_Account0_focus_coins.json
│   ├── bp_Account3_focus_coins.json
│   └── bp_Account4_focus_coins.json
├── MartinHedgeCoins/                  # 马丁策略关注币种配置
│   ├── bp_Account2_focus_coins.json
│   └── bp_Account4_focus_coins.json
├── ProgressiveHedgeCoins/             # 渐进式策略关注币种配置
│   ├── bp_Account0_focus_coins.json
│   └── bp_Account3_focus_coins.json
└── coinPrices_for_openPosition/       # 开仓价格记录
    ├── bp_0_coinPrices_for_openPosition.json
    ├── bp_3_coinPrices_for_openPosition.json
    └── bp_4_coinPrices_for_openPosition.json
```

---

## 🔧 详细配置指南

### 1. 账户配置

#### 添加新账户
```json
{
  "account_ids": [0, 3, 5],           // 添加账户5
  "cexes": ["bp", "bp", "okx"],        // 对应交易所
  "leverages": [0.3, 0.3, 0.5],       // 对应初始杠杆
  "need_to_init": [false, false, true] // 新账户需要初始化
}
```

#### 修改交易所
```json
{
  "account_ids": [0, 3],
  "cexes": ["okx", "bp"],              // 修改交易所
  "leverages": [0.3, 0.3]
}
```

### 2. 杠杆配置

#### 马丁策略杠杆设置
```json
{
  "leverages": [0.3, 0.3],             // 初始杠杆
  "max_leverages": [3.88, 3.88],       // 最大杠杆
  "min_leverages": [0.28, 0.28]        // 最小杠杆
}
```

#### 渐进式策略杠杆设置
```json
{
  "leverages": [0.3, 0.3],             // 初始杠杆
  "max_leverages": [3.28, 3.28],       // 最大杠杆（更保守）
  "min_leverages": [0.28, 0.28]        // 最小杠杆
}
```

### 3. 触发点配置

#### 马丁策略触发点
```json
{
  "add_position_rates": [0.00388, 0.00588],   // 加仓触发比例
  "reduce_position_rates": [0.00488, 0.00688] // 减仓触发比例
}
```

#### 渐进式策略触发点
```json
{
  "add_position_rates": [0.00588, 0.00588],   // 加仓触发比例
  "reduce_position_rates": [0.00588, 0.00588] // 减仓触发比例
}
```

### 4. 币种配置

#### 修改关注币种（传统方式）
编辑 `good_group_bp.txt` 文件：
```
# 第一行：好币种列表
btc,eth,sol,doge,xrp
# 第二行：对应权重
0.4,0.2,0.15,0.15,0.1
# 第三行：坏币种列表（可选）
shib,doge
```

#### 修改关注币种（新方式 - 策略专用文件夹）
每个策略都有独立的关注币种配置文件夹：

**文件夹结构**：
- `SniperCoins/` - 狙击飞升策略关注币种
- `MartinHedgeCoins/` - 马丁对冲网格策略关注币种  
- `ProgressiveHedgeCoins/` - 渐进式对冲网格策略关注币种

**文件命名规则**：`{交易所}_Account{账户ID}_focus_coins.json`

**配置文件格式**：
```json
{
  "good_group": ["btc", "eth", "sol", "doge", "xrp"],
  "bad_coins": ["shib", "doge"],
  "all_coins": ["btc", "eth", "sol", "doge", "xrp", "shib", "doge"],
  "last_updated": 1734624000.0,
  "description": "bp-0 关注币种配置"
}
```

**优势**：
- 每个策略独立配置
- 每个账户独立配置
- 自动持久化存储
- 支持动态更新
- 避免配置冲突
- 策略间完全隔离

#### 狙击策略目标币种
修改 `SniperTakeoffHedge.py` 中的 `target_pool`：
```python
target_pool = {'btc', 'bnb'}  # 当前设置
# target_pool = {'btc', 'eth', 'sol', 'doge', 'xrp'}  # 扩展设置
```

---

## 🛠️ 高级操作

### 1. 断点续传

#### 手动停止
```bash
# 按 Ctrl+C 停止策略
# 状态会自动保存到配置文件
```

#### 重启继续
```bash
# 直接运行，会自动加载上次状态
python apps/strategies/hedge/MartingHedgeGrid.py
```

#### 强制重置
```json
{
  "need_to_init": [true, true],        // 强制重新初始化
  "add_times": [0, 0],                 // 重置加仓次数
  "reduce_times": [0, 0]               // 重置减仓次数
}
```

### 2. 状态监控

#### 实时状态
- 策略运行时会显示：
  - 当前余额
  - 目标余额范围
  - 当前杠杆倍数
  - 运行时间
  - 加仓/减仓次数

#### 配置文件状态
```json
{
  "balances": [1019.0, 4345.6],       // 当前余额
  "leverages": [0.76, 0.44],           // 当前杠杆
  "add_times": [2, 1],                 // 加仓次数
  "reduce_times": [0, 0]               // 减仓次数
}
```

### 3. 关注币种管理

#### 查看当前配置
```bash
# 查看狙击策略关注币种配置
ls apps/strategies/hedge/SniperCoins/

# 查看马丁策略关注币种配置
ls apps/strategies/hedge/MartinHedgeCoins/

# 查看渐进式策略关注币种配置
ls apps/strategies/hedge/ProgressiveHedgeCoins/

# 查看特定账户配置
cat apps/strategies/hedge/SniperCoins/bp_Account0_focus_coins.json
```

#### 手动更新关注币种
```python
# 更新狙击策略关注币种
from apps.strategies.hedge.SniperTakeoffHedge import update_focus_coins
update_focus_coins('bp', 0, new_good_group=['btc', 'eth', 'sol'])

# 更新马丁策略关注币种
from apps.strategies.hedge.MartingHedgeGrid import load_focus_coins, save_focus_coins
coins_config = load_focus_coins('bp', 2)
coins_config['good_group'] = ['btc', 'eth', 'sol']
save_focus_coins('bp', 2, coins_config)

# 更新渐进式策略关注币种
from apps.strategies.hedge.ProgressiveHedgeGrid import load_focus_coins, save_focus_coins
coins_config = load_focus_coins('bp', 0)
coins_config['good_group'] = ['btc', 'eth', 'sol']
save_focus_coins('bp', 0, coins_config)
```

#### 批量初始化关注币种
```bash
# 运行狙击策略，会自动初始化SniperCoins配置
python apps/strategies/hedge/SniperTakeoffHedge.py

# 运行马丁策略，会自动初始化MartinHedgeCoins配置
python apps/strategies/hedge/MartingHedgeGrid.py

# 运行渐进式策略，会自动初始化ProgressiveHedgeCoins配置
conda activate ctos
python apps/strategies/hedge/ProgressiveHedgeGrid.py
```

### 4. 错误处理

#### 常见错误
1. **交易所连接失败**：检查网络和API配置
2. **余额不足**：调整 `leverages` 或 `sanction_money`
3. **币种不存在**：检查 `SniperCoins/` 中的币种名称
4. **关注币种配置缺失**：运行策略自动初始化

#### 恢复操作
```bash
# 删除配置文件重新开始
rm apps/strategies/hedge/marting_hedge_config.json
python apps/strategies/hedge/MartingHedgeGrid.py

# 删除关注币种配置重新初始化
rm -rf apps/strategies/hedge/SniperCoins/
python apps/strategies/hedge/SniperTakeoffHedge.py
```

---

## 🔮 策略扩展

### 1. 新增策略模板

#### 创建新策略文件
```python
# 新策略文件：NewStrategy.py
import os
import sys
import time
import json

def load_strategy_state():
    """加载策略状态配置文件"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(current_dir, "new_strategy_config.json")
    
    default_config = {
        "account_ids": [0, 3],
        "cexes": ["bp", "bp"],
        # 添加你的配置参数
        "description": "新策略配置"
    }
    
    # 配置文件加载逻辑...
    return config

def save_strategy_state(config):
    """保存策略状态到配置文件"""
    # 状态保存逻辑...
    pass

def new_strategy_function(engine, config):
    """新策略核心逻辑"""
    # 你的策略逻辑...
    pass

if __name__ == '__main__':
    # 主函数逻辑...
    pass
```

#### 添加策略到总览
在 `README.md` 的策略总览表格中添加：
```markdown
| **新策略名称** | `NewStrategy.py` | 0, 3 | 策略特点描述 | 适用场景 | ✅ 运行中 |
```

### 2. 配置扩展

#### 新增配置字段
```json
{
  "account_ids": [0, 3],
  "cexes": ["bp", "bp"],
  "new_parameter": "value",              // 新增参数
  "description": "策略配置"
}
```

#### 配置验证
```python
def validate_config(config):
    """验证配置文件"""
    required_fields = ["account_ids", "cexes", "new_parameter"]
    for field in required_fields:
        if field not in config:
            raise ValueError(f"缺少必要字段: {field}")
```

### 3. 监控扩展

#### 新增监控指标
```python
def monitor_strategy_performance(config):
    """监控策略性能"""
    # 添加新的监控指标
    performance_metrics = {
        "total_trades": 0,
        "success_rate": 0.0,
        "max_drawdown": 0.0,
        "new_metric": 0.0  # 新增指标
    }
    return performance_metrics
```

---

## 📞 技术支持

### 1. 常见问题

#### Q: 策略停止后如何重启？
A: 直接运行对应的Python文件即可，会自动加载上次状态。

#### Q: 如何修改策略参数？
A: 编辑对应的配置文件（如 `marting_hedge_config.json`），然后重启策略。

#### Q: 如何添加新的交易所？
A: 在 `cexes` 字段中添加新的交易所名称，确保对应的账户配置正确。

#### Q: 如何监控策略运行状态？
A: 查看控制台输出，或检查配置文件中的状态信息。

### 2. 故障排除

#### 策略无法启动
1. 检查Python环境和依赖
2. 验证交易所API配置
3. 检查网络连接

#### 策略运行异常
1. 查看错误日志
2. 检查配置文件格式
3. 验证账户余额和权限

#### 性能问题
1. 调整触发参数
2. 优化杠杆设置
3. 检查市场条件

---

## 📈 性能优化建议

### 1. 参数调优

#### 杠杆设置
- **高波动市场**：使用马丁策略，设置较高最大杠杆
- **低波动市场**：使用渐进式策略，设置较低最大杠杆
- **趋势市场**：使用狙击策略，设置合适的制裁阈值

#### 触发点设置
- **频繁交易**：降低触发比例
- **减少交易**：提高触发比例
- **平衡设置**：根据历史数据调整

### 2. 风险控制

#### 杠杆控制
- 设置合理的最大杠杆上限
- 监控杠杆使用情况
- 及时调整杠杆策略

#### 资金管理
- 分散账户风险
- 设置止损机制
- 定期检查余额变化

---

## 🔄 更新日志

### v1.0.0 (2025.01.20)
- ✅ 实现马丁对冲网格策略
- ✅ 实现渐进式对冲网格策略  
- ✅ 实现狙击飞升对冲策略
- ✅ 支持断点续传功能
- ✅ 支持多账户多交易所
- ✅ 完整的配置文件系统

### 后续计划
- 🔄 添加更多策略类型
- 🔄 优化性能监控
- 🔄 增强风险控制
- 🔄 支持更多交易所

---

## 📝 注意事项

1. **风险提示**：量化交易存在风险，请谨慎使用
2. **资金安全**：建议使用小资金测试，熟悉策略后再加大投入
3. **参数调整**：根据市场情况及时调整策略参数
4. **监控运行**：定期检查策略运行状态和性能表现
5. **备份配置**：重要配置文件请及时备份

---

*最后更新：2025.01.20*
*版本：v1.0.0*
