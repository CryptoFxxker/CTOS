# -*- coding: utf-8 -*-
# tests/test_execution_engine_simple.py
# 简化版ExecutionEngine测试，快速验证place_incremental_orders功能

import os
import sys
import time
from pathlib import Path

def add_project_paths(project_name="ctos"):
    """
    自动查找项目根目录，并将其及常见子包路径添加到 sys.path。
    :param project_name: 项目根目录标识（默认 'ctos'）
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = None
    # 向上回溯，找到项目根目录
    path = current_dir
    while path != os.path.dirname(path):  # 一直回溯到根目录
        if os.path.basename(path) == project_name or os.path.exists(os.path.join(path, ".git")):
            project_root = path
            break
        path = os.path.dirname(path)
    if not project_root:
        raise RuntimeError(f"未找到项目根目录（包含 {project_name} 或 .git）")
    # 添加根目录
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    return project_root
# 执行路径添加
_PROJECT_ROOT = add_project_paths()
print('_PROJECT_ROOT: ', _PROJECT_ROOT, 'CURRENT_DIR: ', os.path.dirname(os.path.abspath(__file__)))


from ctos.core.runtime.ExecutionEngine import pick_exchange
from ctos.drivers.okx.util import rate_price2order, align_decimal_places, cal_amount, json, BeijingTime


current_dir = os.path.dirname(os.path.abspath(__file__))
config_file = os.path.join(current_dir, "martin_hedge_config.json")
last_config_mtime = os.path.getmtime(config_file)


def load_focus_coins(cex_name, account_id):
    """加载指定交易所和账户的关注币种"""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    MartinHedge_coins_dir = os.path.join(current_dir, "MartinHedgeCoins")
    
    # 确保目录存在
    if not os.path.exists(MartinHedge_coins_dir):
        os.makedirs(MartinHedge_coins_dir)
        print(f"✓ 创建MartinHedgeCoins文件夹: {MartinHedge_coins_dir}")
    
    coins_file = os.path.join(MartinHedge_coins_dir, f"{cex_name}_Account{account_id}_focus_coins.json")
    
    # 默认配置
    default_coins = {
        "good_group": [],
        "bad_coins": [],
        "all_coins": [],
        "last_updated": None,
        "description": f"{cex_name}-{account_id} 关注币种配置",
        "all_rate": [],
        'need_update': False
    }
    
    if os.path.exists(coins_file):
        try:
            with open(coins_file, 'r', encoding='utf-8') as f:
                coins_config = json.load(f)
            print(f"✓ 加载关注币种配置: {coins_file} ", "" if coins_config['need_update'] else "✓ 无需更新")
            if coins_config['need_update']:
                pass
            else:
                return coins_config
        except Exception as e:
            print(f"✗ 加载关注币种配置失败: {e}")
            pass

    # 从good_group文件初始化
    try:
        good_group_file = str(_PROJECT_ROOT) + f'/apps/strategies/hedge/good_group_{cex_name}_martin.txt'
        if os.path.exists(good_group_file):
            with open(good_group_file, 'r', encoding='utf8') as f:
                data = f.readlines()
                good_group = data[0].strip().lower().split(',')
                all_rate = [float(x) for x in data[1].replace(' ', '').replace('，',',').strip().lower().split(',')]
                if len(data) >= 3 and data[2].strip() != '':
                    bad_coins = [x for x in data[2].replace(' ', '').replace('，',',').strip().lower().split(',') if x.lower() not in good_group]
                else:
                    bad_coins = []
                all_coins = good_group + bad_coins
            
            coins_config = {
                "good_group": good_group,
                "all_rate": all_rate,
                "bad_coins": bad_coins,
                "all_coins": all_coins,
                "last_updated": time.time(),
                "description": f"{cex_name}-{account_id} 关注币种配置",
                "need_update": False
            }
            
            # 保存到文件
            with open(coins_file, 'w', encoding='utf-8') as f:
                json.dump(coins_config, f, ensure_ascii=False, indent=2)
            print(f"✓ 初始化关注币种配置: {coins_file}")
            return coins_config
        else:
            print(f"✗ 未找到good_group文件: {good_group_file}")
            return default_coins
    except Exception as e:
        print(f"✗ 初始化关注币种配置失败: {e}")
        return default_coins



def load_strategy_state():
    """加载策略状态配置文件"""

    # 默认配置
    default_config = {
        "account_ids": [0, 3],
        "cexes": ["bp", "bp"],
        "leverages": [0.3, 0.3],
        "start_balances": [1000.0, 1000.0],
        "balances": [1000.0, 1000.0],
        "add_times": [0, 0],
        "reduce_times": [0, 0],
        "max_leverages": [3.28, 3.28],
        "min_leverages": [0.28, 0.28],
        "add_position_rates": [0.00588, 0.00588],
        "reduce_position_rates": [0.00588, 0.00588],
        "description": "渐进式对冲网格策略配置",
        "need_to_init": [True, True]
    }
    
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            print(f"✓ 加载策略配置: {config_file}")
            return config
        except Exception as e:
            print(f"✗ 加载配置文件失败: {e}")
            return default_config
    else:
        # 创建默认配置文件
        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, ensure_ascii=False, indent=2)
            print(f"✓ 创建默认配置文件: {config_file}")
            return default_config
        except Exception as e:
            print(f"✗ 创建配置文件失败: {e}")
            return default_config


def save_strategy_state(config):
    """保存策略状态到配置文件"""
    try:
        with open(config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        print(f"\r✓ 策略状态已保存: {config_file}")
        last_config_mtime = os.path.getmtime(config_file)
    except Exception as e:
        print(f"✗ 保存策略状态失败: {e}")


def set_balance_leverage(cex_name='bp', account=3, strategy='HEDGE', strategy_detail='COMMON', leverage_times=1, engine=None, operate_mode=0, add_times=0, reduce_times=0):
    if engine is None:  
        cex, engine = pick_exchange(cex=cex_name, account=account, strategy=strategy, strategy_detail=strategy_detail)
    else:
        cex = engine.cex_driver.cex if cex_name is None else cex_name
    cex = engine.cex_driver
    all_coins_in_cex, _  = cex.symbols()
    all_coins = []
    for x in all_coins_in_cex:
        if x.find('-') != -1:
            all_coins.append(x[:x.find('-')].lower())
        else:
            all_coins.append(x[:x.find('_')].lower())
    print('all_coins: ', all_coins, 'len(all_coins): ', len(all_coins))

    coins_config = load_focus_coins(cex_name, account)
    good_group = coins_config["good_group"]
    all_rate = coins_config["all_rate"]
    bad_coins = coins_config["bad_coins"]
    filtered_good_group = []
    filtered_all_rate = []
    for i, coin in enumerate(good_group):
        if coin in all_coins:
            filtered_good_group.append(coin)
            filtered_all_rate.append(all_rate[i])
    good_group = filtered_good_group
    all_rate = filtered_all_rate
    # 如果加仓次数大于0，则增加BTC分配比例（all_rate[0]），但不能超过其他币种总分配和，否则设置为0.5
    if add_times > 0:
        all_rate[0] = all_rate[0] * (1 + add_times/20) if all_rate[0] * (1 + add_times/20) < sum(all_rate[1:]) else sum(all_rate[1:])
    # 如果减仓次数大于0，则减少BTC分配比例（all_rate[0]），但不能低于所有币种平均分配，否则设置为平均分配
    if reduce_times > 0:
        all_rate[0] = all_rate[0] * (1 - reduce_times/20) if all_rate[0] * (1 - reduce_times/20) < 1/len(all_rate) * sum(all_rate[1:]) else round(1/len(all_rate)* sum(all_rate[1:]), 2)
    btc_rate = all_rate[0] / sum(all_rate)
    split_rate = {good_group[x + 1]: all_rate[x + 1] / sum(all_rate) for x in range(len(all_rate) - 1)}

    start_money = cex.fetch_balance()
    if bad_coins:
        all_coins_to_trade = list(set(bad_coins + good_group))
    else:
        all_coins_to_trade = list(set(good_group + [k for k,_ in rate_price2order.items() if k in all_coins]))
    print(f"start_money: {start_money}, len(all_coins_to_trade): {len(all_coins_to_trade)}")
    usdt_amounts = []
    coins_to_deal = []
    is_btc_failed = False
    thistime_operate_position = round(start_money * leverage_times, 2)
    for coin in set(all_coins_to_trade):
        if coin in good_group:
            operate_amount = cal_amount(coin, thistime_operate_position, good_group, btc_rate, split_rate)
            if is_btc_failed:
                operate_amount = -operate_amount
            usdt_amounts.append(operate_amount)
            coins_to_deal.append(coin)
        else:
            sell_amount = thistime_operate_position / (len(all_coins_to_trade) - len(good_group))
            if is_btc_failed:
                sell_amount = -sell_amount
            sell_amount = -sell_amount
            usdt_amounts.append(sell_amount)
            coins_to_deal.append(coin)
    print('usdt_amounts: ', usdt_amounts, 'coins_to_deal: ', coins_to_deal)
    if operate_mode == 0:
        focus_orders = engine.set_coin_position_to_target(usdt_amounts, coins_to_deal, soft=False, async_mode=True, stack_mode=False)
        # if engine.account != 3:
        #     engine.focus_on_orders(all_coins_to_trade, focus_orders)
        #     while len(engine.watch_threads) > 0:
        #         time.sleep(1)
    elif operate_mode == 1:
        focus_orders = engine.set_coin_position_to_target(usdt_amounts, coins_to_deal, soft=False, async_mode=True, stack_mode=True)
        # for usdt_amount, coin in zip(usdt_amounts, coins_to_deal):
        #     engine.place_incremental_orders(abs(usdt_amount), coin, 'buy' if usdt_amount > 0 else 'sell', soft=False)
    elif operate_mode == -1:
        focus_orders = engine.set_coin_position_to_target(usdt_amounts, coins_to_deal, soft=False, async_mode=True, stack_mode=True)
        # for usdt_amount, coin in zip(usdt_amounts, coins_to_deal):
        #     engine.place_incremental_orders(abs(usdt_amount), coin, 'sell' if usdt_amount > 0 else 'buy', soft=False)
    time.sleep(1)

if __name__ == '__main__':
    # 加载策略配置
    config = load_strategy_state()
    
     # 自动用当前文件名（去除后缀）作为默认策略名，细节默认为COMMON
    default_strategy = os.path.splitext(os.path.basename(__file__))[0].upper()
    
    # 从配置文件获取参数
    account_ids = config["account_ids"]
    cexes = config["cexes"]
    leverages = config["leverages"]
    start_balances = config["start_balances"]
    balances = config["balances"]
    add_times = config["add_times"]
    reduce_times = config["reduce_times"]
    max_leverages = config["max_leverages"]
    min_leverages = config["min_leverages"]
    add_position_rates = config["add_position_rates"]
    reduce_position_rates = config["reduce_position_rates"]
    need_to_init = config["need_to_init"]
    need_to_reset_base_balance = config["need_to_reset_base_balance"]
    
    # 初始化交易所和引擎
    engines = []
    for i, (cex, account) in enumerate(zip(cexes, account_ids)):
        try:
            exch, engine = pick_exchange(cex, account, strategy=default_strategy, strategy_detail="COMMON")
            engines.append(engine)
            print(f"✓ 初始化 {cex}-{account} 成功")
        except Exception as e:
            print(f"✗ 初始化 {cex}-{account} 失败: {e}")
            continue
    
    if not engines:
        print("❌ 没有成功初始化任何交易所，退出")
        sys.exit(1)
    
    # 获取当前余额（如果配置文件中的余额为默认值，则获取实际余额）
    for i, engine in enumerate(engines):
        if need_to_init[i]:
            add_times[i] = 0
            reduce_times[i] = 0
        if balances[i] == 1000.0:  # 默认值，获取实际余额
            balances[i] = engine.cex_driver.fetch_balance()
            start_balances[i] = balances[i]
            print(f"✓ 获取实际余额 {cexes[i]}-{account_ids[i]}: {balances[i]}")
    
    # 初始化策略
    for idx in range(len(engines)):
        if need_to_init[idx]:
            add_times[idx] = 0
            reduce_times[idx] = 0
            print(f"{BeijingTime()} 初始化 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
            set_balance_leverage(cex_name=cexes[idx], account=account_ids[idx], strategy=default_strategy, strategy_detail='COMMON', leverage_times=leverages[idx], engine=engines[idx], operate_mode=0)
            print(f"{BeijingTime()} 初始化完成 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
            need_to_init[idx] = False
        if need_to_reset_base_balance[idx]:
            balances[idx] = engines[idx].cex_driver.fetch_balance()
            print(f"✓ 更新获取实际余额 {cexes[idx]}-{account_ids[idx]}: {balances[idx]}")
            need_to_reset_base_balance[idx] = False
            config.update({
                "balances": balances,
                "need_to_reset_base_balance": need_to_reset_base_balance,
                "leverages": leverages,
                "add_times": add_times,
                "reduce_times": reduce_times,
                "need_to_init": need_to_init
            })
    save_strategy_state(config)

    print(f"🚀 启动渐进式对冲网格策略，共 {len(engines)} 个账户")
    start_time = time.time()
    now_balances = [0] * len(engines)
    try:
        while True:
            # 检查配置文件是否被修改，热更新参数
            current_mtime_forfile = os.path.getmtime(config_file)
            if current_mtime_forfile != last_config_mtime:
                print(f"{BeijingTime()} 检测到配置文件有更改，重新加载配置...")
                with open(config_file, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                # 更新本地变量
                start_balances = config["start_balances"]
                balances = config["balances"]
                add_times = config["add_times"]
                reduce_times = config["reduce_times"]
                max_leverages = config["max_leverages"]
                min_leverages = config["min_leverages"]
                add_position_rates = config["add_position_rates"]
                reduce_position_rates = config["reduce_position_rates"]
                need_to_init = config.get("need_to_init", need_to_init)
                change_position_ratio_once = config.get("change_position_ratio_once", [0]*len(engines))
                last_config_mtime = current_mtime_forfile
            need_save_configs = False
            for idx in range(len(engines)):
                try:

                    if need_to_init[idx]:
                        add_times[idx] = 0
                        reduce_times[idx] = 0
                        print(f"{BeijingTime()} 初始化 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
                        set_balance_leverage(cex_name=cexes[idx], account=account_ids[idx], strategy=default_strategy, strategy_detail='COMMON', leverage_times=leverages[idx], engine=engines[idx], operate_mode=0)
                        print(f"{BeijingTime()} 初始化完成 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
                        need_to_init[idx] = False
                        need_save_configs = True
                    if change_position_ratio_once[idx] != 0:
                        print(f"{BeijingTime()} 修改仓位比例 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
                        set_balance_leverage(cex_name=cexes[idx], account=account_ids[idx], strategy=default_strategy, strategy_detail='COMMON', leverage_times=abs(float(change_position_ratio_once[idx])), engine=engines[idx], operate_mode=1 if change_position_ratio_once[idx] > 0 else -1)
                        print(f"{BeijingTime()} 修改仓位比例完成 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
                        leverages[idx] += change_position_ratio_once[idx]
                        change_position_ratio_once[idx] = 0
                        need_save_configs = True
                    now_balance = round(engines[idx].cex_driver.fetch_balance(), 2)
                    now_balances[idx] = now_balance
                    base_balance = round(balances[idx], 2)
                    add_position_rate = add_position_rates[idx]
                    reduce_position_rate = reduce_position_rates[idx]
                    max_leverage = max_leverages[idx]
                    min_leverage = min_leverages[idx]

                    down_target_balance = round(base_balance - base_balance * leverages[idx] * add_position_rate, 2)
                    up_target_balance = round(base_balance + 2 * base_balance * leverages[idx] * reduce_position_rate, 2)

                    if now_balance < down_target_balance and leverages[idx] < max_leverage and now_balance < start_balances[idx]:
                        add_times[idx] += 1
                        reduce_times[idx] = 0
                        leverage_change = 0.033 * pow(2, add_times[idx]/2)
                        leverages[idx] += leverage_change
                        balances[idx] = now_balance
                        print(f"{BeijingTime()} 加仓 {cexes[idx]} - {account_ids[idx]} - Base:{balances[idx]} 开始")
                        set_balance_leverage(cex_name=cexes[idx], account=account_ids[idx], strategy=default_strategy, strategy_detail='COMMON', leverage_times=leverage_change, engine=engines[idx], operate_mode=1, add_times=add_times[idx])
                        print(f"{BeijingTime()} 加仓完成 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")

                    elif leverages[idx] > min_leverage and now_balance > start_balances[idx] * (1+reduce_position_rate):
                        if start_balances[idx] < now_balance:
                            start_balances[idx] = now_balance
                        reduce_times[idx] += 1
                        # 每次减仓时将 add_times[idx] 归零，意味着每新增一层仓位后，
                        # “加仓”计数需重新归零，防止加减交互导致重复递增杠杆。
                        # 这样只有一连串跌势（触发多次加仓）才会推进杠杆递增，
                        # 而不是加减交错，提升了调整的稳定性，也是网格马丁加减模式的常见技巧。
                        leverage_change = 0.033 * pow(2, add_times[idx]/2)
                        add_times[idx] -= 1
                        if add_times[idx] < 0:
                            add_times[idx] = 0
                        leverages[idx] -= leverage_change
                        balances[idx] += base_balance * leverages[idx] * add_position_rate
                        print(f"{BeijingTime()} 减仓 {cexes[idx]} - {account_ids[idx]} - {balances[idx]} 开始")
                        set_balance_leverage(cex_name=cexes[idx], account=account_ids[idx], strategy=default_strategy, strategy_detail='COMMON', leverage_times=leverage_change, engine=engines[idx], operate_mode=-1, reduce_times=reduce_times[idx])
                        print(f"{BeijingTime()} 减仓完成 {cexes[idx]} - {account_ids[idx]} - {balances[idx]}")
                        
                    else:
                        elapsed_seconds = int(time.time() - start_time)
                        days, remainder = divmod(elapsed_seconds, 86400)
                        hours, remainder = divmod(remainder, 3600)
                        minutes, _ = divmod(remainder, 60)
                        print(f"\r{BeijingTime()} {cexes[idx]}-{account_ids[idx]} [{round(down_target_balance,2)} {round(now_balance,2)} {round(up_target_balance,2)}], Base:{round(balances[idx],2)}->{round(start_balances[idx],2)} | L:{round(leverages[idx],2)} | Ba:{[int(x) for x in now_balances]} | {days}天{hours}时{minutes}分【复利，勿人】", end='')
                        time.sleep(2.88)

                except Exception as e:
                    print(f"{BeijingTime()} 账户 {cexes[idx]} - {account_ids[idx]} 操作失败: {e}")
            if need_save_configs:
                config.update({
                    "balances": balances,
                    "start_balances": start_balances,
                    "leverages": leverages,
                    "add_times": add_times,
                    "reduce_times": reduce_times,
                    "need_to_init": need_to_init,
                    "change_position_ratio_once": change_position_ratio_once
                })
                need_save_configs = False
                save_strategy_state(config)
                time.sleep(6.66)

            # 定期保存状态（每30分钟）
            if time.time() - start_time % (60 * 30) in [0, 1, 2]:
                config.update({
                    "balances": balances,
                    "start_balances": start_balances,
                    "leverages": leverages,
                    "add_times": add_times,
                    "reduce_times": reduce_times,
                    "need_to_init": need_to_init,
                    "change_position_ratio_once": change_position_ratio_once
                })
                save_strategy_state(config)
                need_save_configs = False
                time.sleep(6.66)
            
    except KeyboardInterrupt:
        print(f"\n{BeijingTime()} 手动停止策略")
        # 保存最终状态
        config.update({
            "balances": balances,
            "start_balances": start_balances,
            "leverages": leverages,
            "add_times": add_times,
            "reduce_times": reduce_times,
            "need_to_init": need_to_init,
            "change_position_ratio_once": change_position_ratio_once
        })
        save_strategy_state(config)
        print("\r✓ 策略状态已保存，重启后可继续运行")
        sys.exit(0)
    except Exception as e:
        print(f"\n{BeijingTime()} 策略运行异常: {e}")
        # 保存异常状态
        config.update({
            "balances": balances,
            "start_balances": start_balances,
            "leverages": leverages,
            "add_times": add_times,
            "reduce_times": reduce_times,
            "need_to_init": need_to_init,
            "change_position_ratio_once": change_position_ratio_once
        })
        save_strategy_state(config)
        print("✓ 异常状态已保存，重启后可继续运行")
        sys.exit(1)